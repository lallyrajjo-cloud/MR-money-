# MR MONEY — Android source

यह Android project आपके **MR MONEY** हिसाब ऐप का WebView-based Android wrapper है। ऐप का नाम MR MONEY है और launcher icon में दिया गया फोटो इस्तेमाल किया गया है।

## मुख्य सुविधाएँ
- ग्राहक: नाम, मोबाइल, पता, फोटो
- लेना/देना और auto balance
- Simple / Compound ब्याज
- घर / Personal खर्च
- UPI payment link
- WhatsApp और SMS statement
- PDF / Print statement (device/browser support पर निर्भर)
- भुगतान reminder list
- Backup / Restore
- Local storage; डेटा डिवाइस में रहता है

## Build
Android Studio या किसी CI/build service में इस folder को Android/Gradle project के रूप में upload करें।

Release APK:
`./gradlew assembleRelease`

APK मिलेगा:
`app/build/outputs/apk/release/app-release.apk`

यदि build service Gradle wrapper मांगती है, वह अपने supported Gradle version से project को build कर सकती है। Project Android Gradle Plugin 8.7.3 और compileSdk 35 पर सेट है।

## GitHub Actions
`.github/workflows/build-apk.yml` workflow release APK बनाकर artifact में upload करता है।

## Package
`com.mrmoney.hisab`

## Icon
`app/src/main/res/mipmap-*/ic_launcher.png` में आपका दिया हुआ फोटो आधारित icon है।
